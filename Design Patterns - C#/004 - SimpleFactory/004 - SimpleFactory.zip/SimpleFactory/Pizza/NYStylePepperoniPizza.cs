﻿namespace SimpleFactory
{
    internal class NYStylePepperoniPizza : Pizza
    {
    }
}