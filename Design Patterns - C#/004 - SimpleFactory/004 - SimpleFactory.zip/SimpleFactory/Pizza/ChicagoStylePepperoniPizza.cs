﻿namespace SimpleFactory
{
    internal class ChicagoStylePepperoniPizza : Pizza
    {
    }
}