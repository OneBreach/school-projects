﻿namespace SimpleFactory
{
    internal class ChicagoStyleCheesePizza : Pizza
    {
    }
}