﻿namespace SimpleFactory
{
    internal class ChicagoStyleClamPizza : Pizza
    {
    }
}