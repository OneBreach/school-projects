﻿namespace SimpleFactory
{
    internal class NYStyleClamPizza : Pizza
    {
    }
}