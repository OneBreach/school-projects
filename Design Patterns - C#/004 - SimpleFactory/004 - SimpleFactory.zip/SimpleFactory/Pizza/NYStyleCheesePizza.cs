﻿namespace SimpleFactory
{
    internal class NYStyleCheesePizza : Pizza
    {
    }
}