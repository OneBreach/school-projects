﻿namespace SimpleFactory
{
    internal class NYStyleVeggiePizza : Pizza
    {
    }
}