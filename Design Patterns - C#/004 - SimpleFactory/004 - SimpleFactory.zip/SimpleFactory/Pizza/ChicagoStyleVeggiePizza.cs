﻿namespace SimpleFactory
{
    internal class ChicagoStyleVeggiePizza : Pizza
    {
    }
}