﻿using StrategyPattern.Behaviours;
using StrategyPattern.Ducks;
using StrategyPattern.Interfaces.FlyBehavior;
using System.Runtime.CompilerServices;

namespace StrategyPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Duck mallardDuck = new MallardDuck();
            Duck redheadDuck = new RedheadDuck();
            Duck decoyDuck = new DecoyDuck();
            Duck rubberDuck = new RubberDuck();
            Duck RoboDuck = new RoboDuck();

            Console.WriteLine("duck-1");
            mallardDuck.Display();
            mallardDuck.Fly();
            mallardDuck.Quack();
            mallardDuck.Swim();
            Console.WriteLine("duck-2");
            decoyDuck.Display();
            decoyDuck.Fly();
            decoyDuck.Quack();
            decoyDuck.Swim();
            Console.WriteLine("duck-3");
            rubberDuck.Display();
            rubberDuck.Fly();
            rubberDuck.Quack();
            rubberDuck.Swim();
            Console.WriteLine("duck-4");
            redheadDuck.Display();
            redheadDuck.Fly();
            redheadDuck.SetQuackBehavior(new Squeack());
            redheadDuck.Swim();
            Console.WriteLine("duck-5");
            RoboDuck.Display();
            RoboDuck.Fly();
            RoboDuck.Swim();
            RoboDuck.Quack();

        }
    }
}