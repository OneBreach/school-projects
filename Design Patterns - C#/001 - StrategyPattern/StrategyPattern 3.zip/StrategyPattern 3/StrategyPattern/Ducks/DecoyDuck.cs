﻿using StrategyPattern.Behaviours;
using StrategyPattern.Interfaces.FlyBehavior;
using StrategyPattern.Interfaces.SwimBehavior;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern.Ducks
{   
    internal class DecoyDuck : Duck
    {
        public DecoyDuck()
        {
            this.flyBehavior = new FlyWithWings();
            this.quackBehavior = new MuteQuack();
            this.swimBehavior = new SwimWithWings();
        }
        public override void Display()
        {
            Console.WriteLine("I'm a Decoy Duck");
        }
    }
}
