﻿using StrategyPattern.Interfaces.FlyBehavior;
using StrategyPattern.Interfaces.QuackBehavior;
using StrategyPattern.Interfaces.SwimBehavior;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern.Ducks
{
    internal abstract class Duck
    {
        protected FlyBehavior flyBehavior { get; set; }
        protected QuackBehavior quackBehavior { get; set; }

        protected SwimBehavior swimBehavior { get; set; }


        public abstract void Display();

        public void Quack()
        {
            quackBehavior.Quack();
        }

        public void Fly()
        {
            flyBehavior.Fly();
        }

        public void Swim()
        {
            swimBehavior.Swim();
        }
        public void SetQuackBehavior(QuackBehavior quackBehavior)
        {
            this.quackBehavior = quackBehavior;
        }
        public void SetFlyBehavior(FlyBehavior flyBehavior)
        {
            this.flyBehavior = flyBehavior;
        }
        public void SetSwimBehavior(SwimBehavior swimBehavior)
        {
            this.swimBehavior = swimBehavior;
        }
    }
}
