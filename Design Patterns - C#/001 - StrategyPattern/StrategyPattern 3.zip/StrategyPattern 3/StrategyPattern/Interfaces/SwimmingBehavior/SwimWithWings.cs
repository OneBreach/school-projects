﻿namespace StrategyPattern.Interfaces.SwimBehavior
{
    internal class SwimWithWings : SwimBehavior
    {
        public void Swim()
        {
            Console.WriteLine("I am swimming with my wings!!!");
        }
    }
}
