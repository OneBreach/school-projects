﻿using StrategyPattern.Interfaces.SwimBehavior;
using StrategyPattern.Interfaces.SwimBehavior;

namespace StrategyPattern.Behaviours
{
    internal class Swim : SwimBehavior
    {
        void SwimBehavior.Swim()
        {
            throw new NotImplementedException();
        }
    }
}
