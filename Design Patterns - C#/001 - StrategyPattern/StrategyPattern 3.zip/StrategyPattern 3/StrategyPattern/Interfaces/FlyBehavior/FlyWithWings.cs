﻿namespace StrategyPattern.Interfaces.FlyBehavior
{
    internal class FlyWithWings : FlyBehavior
    {
        public void Fly()
        {
            Console.WriteLine("I am flying with my wings");
        }
    }
}
