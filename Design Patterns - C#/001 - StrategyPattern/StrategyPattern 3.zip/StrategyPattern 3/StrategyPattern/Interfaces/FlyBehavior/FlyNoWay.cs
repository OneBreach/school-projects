﻿using StrategyPattern.Interfaces.FlyBehavior;

namespace StrategyPattern.Behaviours
{
    internal class FlyNoWay : FlyBehavior
    {

        public void Fly()
        {
            Console.WriteLine("I cannot fly!");
        }
    }
}
