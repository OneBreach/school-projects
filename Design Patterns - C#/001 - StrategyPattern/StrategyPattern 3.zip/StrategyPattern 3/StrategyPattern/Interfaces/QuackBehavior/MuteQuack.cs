﻿using StrategyPattern.Interfaces.QuackBehavior;

namespace StrategyPattern.Behaviours
{
    internal class MuteQuack : QuackBehavior
    {
        public void Quack()
        {
            Console.WriteLine("I can't Quack");
        }
    }
}
