﻿using StrategyPattern.Interfaces.QuackBehavior;

namespace StrategyPattern.Behaviours
{
    internal class Squeack : QuackBehavior
    {
        void QuackBehavior.Quack()
        {
            Console.WriteLine("Squeack");
        }
    }
}
