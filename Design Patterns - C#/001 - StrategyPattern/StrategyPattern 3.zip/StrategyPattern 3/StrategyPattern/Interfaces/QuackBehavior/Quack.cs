﻿using StrategyPattern.Interfaces.QuackBehavior;

namespace StrategyPattern.Behaviours
{
    internal class Quack : QuackBehavior
    {
        void QuackBehavior.Quack()
        {
            Console.WriteLine("Quack");
        }
    }
}
