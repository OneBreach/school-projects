﻿using AdapterPattern.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdapterPattern
{
    internal class CanadaGoose : Goose
    {
        public void Fly()
        {
            Console.WriteLine("Goose fly");
        }

        public void Honk()
        {
            Console.WriteLine("Goose Honk");
        }
    }
}
