﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdapterPattern.Interfaces
{
    internal class GooseAdapter : Duck
    {
        private Turkey turkey;
        public GooseAdapter(Goose goose)
        {
            this.goose = goose;
        }
        public void Quack()
        {
            goose.Gobble();
        }

        public void Honk()
        {
                goose.Fly();        
        }
    }
}
