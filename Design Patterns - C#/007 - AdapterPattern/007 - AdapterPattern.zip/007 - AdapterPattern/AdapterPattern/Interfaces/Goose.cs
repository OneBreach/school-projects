﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdapterPattern.Interfaces
{
    internal interface Goose
    {
        public void Honk();
        public void Fly();
    }
}
