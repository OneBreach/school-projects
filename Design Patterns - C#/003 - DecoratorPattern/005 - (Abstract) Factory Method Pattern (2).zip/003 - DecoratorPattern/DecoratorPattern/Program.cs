﻿using DecoratorPattern.Beverages;
using DecoratorPattern.Condiments;

namespace DecoratorPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Beverage espresso = new Espresso();
            PrintBeverage(espresso);

            Beverage doppio = new Espresso();
            doppio = new Espresso(doppio);
            PrintBeverage(doppio);


            Beverage lungo = new Espresso();
            lungo = new Water(lungo);
            PrintBeverage(lungo);

            Beverage corretta = new Espresso();
            corretta = new MilkFoam(corretta);
            PrintBeverage(corretta);


            Beverage con_panna = new Espresso();
            con_panna = new Whip(con_panna);
            PrintBeverage(con_panna);

            Beverage americano = new Espresso();
            americano = new Water(americano);
            americano = new Water(americano);
            PrintBeverage(americano);

            Beverage caffe_latte = new Espresso();
            caffe_latte = new SteamedMilk(caffe_latte);
            caffe_latte = new SteamedMilk(caffe_latte);
            caffe_latte = new SteamedMilk(caffe_latte);
            caffe_latte = new SteamedMilk(caffe_latte);
            caffe_latte = new SteamedMilk(caffe_latte);
            caffe_latte = new MilkFoam(caffe_latte);
            PrintBeverage(caffe_latte);

            Beverage romana = new Espresso();
            romana = new Lemon(romana);
            PrintBeverage(romana);




            BeverageFactory factory = new BeverageFactory();
            Console.WriteLine("Factory");
            PrintBeverage(factory.CreateBeverage(Drink.espresso, Size.GRANDE));
            PrintBeverage(factory.CreateBeverage(Drink.doppio, Size.TALL));
            PrintBeverage(factory.CreateBeverage(Drink.lungo, Size.VENDI));
            PrintBeverage(factory.CreateBeverage(Drink.corretta, Size.VENDI));
            PrintBeverage(factory.CreateBeverage(Drink.con_panna, Size.VENDI));
            PrintBeverage(factory.CreateBeverage(Drink.americano, Size.GRANDE));
            PrintBeverage(factory.CreateBeverage(Drink.caffe_latte, Size.TALL));
            PrintBeverage(factory.CreateBeverage(Drink.mocha, Size.TALL));
            PrintBeverage(factory.CreateBeverage(Drink.iced_espresso, Size.TALL));
            PrintBeverage(factory.CreateBeverage(Drink.affogato, Size.TALL));
            PrintBeverage(factory.CreateBeverage(Drink.honey_latte, Size.TALL));
            PrintBeverage(factory.CreateBeverage(Drink.chocolate, Size.TALL));
            PrintBeverage(factory.CreateBeverage(Drink.chocolate_with_cream, Size.TALL));
            PrintBeverage(factory.CreateBeverage(Drink.chocolate_with_milk, Size.TALL));

        }

        static void PrintBeverage(Beverage beverage)
        {
            Console.WriteLine(beverage.GetDescription() + " $" + beverage.cost().ToString("#.##"));
        }
    }
}