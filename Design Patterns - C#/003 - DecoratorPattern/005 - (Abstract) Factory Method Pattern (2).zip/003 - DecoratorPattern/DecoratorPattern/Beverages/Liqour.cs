namespace DecoratorPattern.Beverages
{
    internal class Liqour : Beverage
    {
        public Liqour(Beverage beverage = null, Size size = Size.GRANDE) : base(size)
        {
            description = "Liqour";
            this.baseBeverage = beverage;
            this.Size = size;

        }
        public override string GetDescription()
        {
            if (baseBeverage != null)
            {
                return baseBeverage.GetDescription() + ", " + description;
            }
            return description;
        }
        public override double cost()
        {
            if (baseBeverage != null)
            {
                return 0.50 + baseBeverage.cost();
            }
            return 0.50;
        }
    }
}
