﻿namespace DecoratorPattern.Beverages
{
    internal class Espresso : Beverage
    {
        public Espresso(Beverage beverage = null, Size size = Size.GRANDE) : base(size)
        {
            description = "Espresso";
            this.baseBeverage = beverage;
            this.Size = size;

        }
        public override string GetDescription()
        {
            if (baseBeverage != null)
            {
                return baseBeverage.GetDescription() + ", " + description;
            }
            return description;
        }
        public override double cost()
        {
            if (baseBeverage != null)
            {
                return 1.99 + baseBeverage.cost();
            }
            return 1.99;
        }
    }
}
