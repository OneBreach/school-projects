﻿namespace DecoratorPattern.Beverages
{
    enum Size
    {
        TALL = 1,
        GRANDE,
        VENDI
    }
    internal abstract class Beverage
    {
        public Size Size
        {
            get
            {
                if (baseBeverage != null)
                {
                    return baseBeverage.Size;
                }
                return size;
            }

            set
            {
                this.size = value;
            }
        }
        private Size size;

        protected string description = "Unknown";
        protected Beverage baseBeverage = null;

        protected Beverage(Size size = Size.GRANDE)
        {
            this.size = size;
        }

        public virtual string GetDescription()
        {
            return description;
        }

        public abstract double cost();
    }
}
