﻿using DecoratorPattern.Beverages;
using DecoratorPattern.Condiments;

namespace DecoratorPattern
{
    public enum Drink
    {
        espresso,
        doppio,
        lungo,
        corretta,
        con_panna,
        americano,
        caffe_latte,
        mocha,
        iced_espresso,
        affogato,
        honey_latte,
        // chocolate drinken
        chocolate,
        chocolate_with_milk,
        chocolate_with_cream
    }

    internal class BeverageFactory
    {
        public BeverageFactory() { }

        public Beverage CreateBeverage(Drink name, Size size)
        {
            switch (name)
            {
                case Drink.espresso:
                    return new Espresso(null, size);

                case Drink.doppio:
                    Beverage doppio = new Espresso(null, size);
                    return new Espresso(doppio);

                case Drink.lungo:
                    Beverage lungo = new Espresso(null, size);
                    return new Water(lungo);

                case Drink.corretta:
                    Beverage corretta = new Espresso(null, size);
                    return new Lemon(corretta);

                case Drink.con_panna:
                    Beverage conPanna = new Espresso(null, size);
                    return new Whip(conPanna);

                case Drink.americano:
                    Beverage americano = new Espresso(null, size);
                    americano = new Water(americano);
                    return new Water(americano);

                case Drink.caffe_latte:
                    Beverage caffeLatte = new Espresso(null, size);
                    caffeLatte = new SteamedMilk(caffeLatte);
                    caffeLatte = new SteamedMilk(caffeLatte);
                    return new MilkFoam(caffeLatte);

                case Drink.mocha:
                    Beverage mocha = new Espresso(null, size);
                    mocha = new SteamedMilk(mocha);
                    return new Mocha(mocha);

                case Drink.iced_espresso:
                    Beverage icedEspresso = new Espresso(null, size);
                    return new Ice(icedEspresso);

                case Drink.affogato:
                    Beverage affogato = new Espresso(null, size);
                    return new IceCream(affogato);

                case Drink.honey_latte:
                    Beverage honeyLatte = new Espresso(null, size);
                    honeyLatte = new SteamedMilk(honeyLatte);
                    honeyLatte = new Honey(honeyLatte);
                    return new MilkFoam(honeyLatte);

                // Nieuwe chocolate drinkenn
                case Drink.chocolate:
                    return new Chocolate(null, size); // Basic chocolate drink.

                case Drink.chocolate_with_milk:
                    Beverage chocolateWithMilk = new Chocolate(null, size);
                    return new SteamedMilk(chocolateWithMilk);

                case Drink.chocolate_with_cream:
                    Beverage chocolateWithCream = new Chocolate(null, size);
                    return new Whip(chocolateWithCream); 
            }

            throw new ArgumentException("Ongeldige drankoptie: " + name);

        }
    }
}
