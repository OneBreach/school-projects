﻿namespace Singleton
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ChocolateBoiler boiler = ChocolateBoiler.GetInstance();
            boiler.drain();
            Console.WriteLine("drain");
            Console.WriteLine(boiler.IsBoiled);
            Console.WriteLine(boiler.IsEmpty);
            boiler.fill();
            Console.WriteLine("fill");
            Console.WriteLine(boiler.IsBoiled);
            Console.WriteLine(boiler.IsEmpty);
            boiler.boil();
            Console.WriteLine("boil");
            Console.WriteLine(boiler.IsBoiled);
            Console.WriteLine(boiler.IsEmpty);

        }
    }
}