﻿namespace FacadePattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
                        Amplifier amp = new Amplifier();
                        CdPlayer cdPlayer = new CdPlayer(amp);
                        DvdPlayer dvdPlayer = new DvdPlayer(amp);
                        PopcornPopper popcornPopper = new PopcornPopper();
                        Projector projector = new Projector();
                        Screen screen = new Screen();
                        TheaterLights lights = new TheaterLights();
                        Tuner tuner = new Tuner(amp);
                        LawOfDementer lawOfDementer = new LawOfDementer();
                        HomeTheaterFacade homeTheater = new HomeTheaterFacade(
                            amp, cdPlayer, dvdPlayer, popcornPopper, projector, screen, lights, tuner, lawOfDementer
                        );


            homeTheater.WatchMovie("Inception");
            Console.WriteLine("Enjoy your movie!");

 
            homeTheater.EndMovie();
            Console.WriteLine("Movie ended.");


            homeTheater.ListenToCd();
            Console.WriteLine("Listening to a CD...");


            homeTheater.EndCd();
            Console.WriteLine("CD playback ended.");


            homeTheater.ListenToRadio(98.5);
            Console.WriteLine("Listening to the radio...");


            homeTheater.EndRadio();
            Console.WriteLine("Radio playback ended.");


            /*popcornPopper.On();
            popcornPopper.Pop();

            lights.Dim(10);

            screen.Down();

            projector.On();
            projector.SetInput(dvdPlayer);
            projector.WideScreenMode();

            amp.On();
            amp.SetDvd(dvdPlayer);
            amp.SetSurroundSound();
            amp.SetVolume(5);

            dvdPlayer.On();
            dvdPlayer.Play("Die Hard");*/
        }
    }
}