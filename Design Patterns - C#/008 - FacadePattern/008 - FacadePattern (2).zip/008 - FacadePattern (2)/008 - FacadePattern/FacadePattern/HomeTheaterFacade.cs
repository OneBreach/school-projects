﻿namespace FacadePattern
{
    internal class HomeTheaterFacade
    {
        private Amplifier amplifier;
        private CdPlayer cdPlayer;
        private DvdPlayer dvdPlayer;
        private PopcornPopper popcornPopper;
        private Projector projector;
        private Screen screen;
        private TheaterLights theaterLights;
        private Tuner tuner;
        private LawOfDementer lawOfDementer;

        // Constructor zonder parameters
        public HomeTheaterFacade(Amplifier amplifier, CdPlayer cdPlayer, DvdPlayer dvdPlayer, PopcornPopper popcornPopper, Projector projector, Screen screen, TheaterLights theaterLights, Tuner tuner, LawOfDementer lawOfDementer)
        {
            this.amplifier = amplifier;
            this.cdPlayer = cdPlayer;
            this.dvdPlayer = dvdPlayer;
            this.popcornPopper = popcornPopper;
            this.projector = projector;
            this.screen = screen;
            this.theaterLights = theaterLights;
            this.tuner = tuner;
            this.lawOfDementer = lawOfDementer;
        }

            public void WatchMovie(string movie)
            {
                popcornPopper.On();
                popcornPopper.Pop();
                theaterLights.Dim(10);
                screen.Down();
                projector.On();
                projector.SetInput(dvdPlayer);
                amplifier.On();
                amplifier.SetDvd(dvdPlayer);
                amplifier.SetSurroundSound();
                amplifier.SetVolume(5);
                dvdPlayer.On();
                dvdPlayer.Play(movie);
            }

        public void EndMovie()
        {
            dvdPlayer.Stop();
            dvdPlayer.Off();
            amplifier.Off();
            projector.Off();
            screen.Up();
            theaterLights.On();
            popcornPopper.Off();
        }

        public void ListenToCd()
        {
            amplifier.On();
            cdPlayer.On();
            amplifier.SetCd(cdPlayer);
            amplifier.SetVolume(5);
            cdPlayer.Play();
        }

        public void EndCd()
        {
            cdPlayer.Stop();
            cdPlayer.Off();
            amplifier.Off();
        }

        public void ListenToRadio(double frequency)
        {
            tuner.On();
            amplifier.On();
            amplifier.SetTuner(tuner);
            amplifier.SetVolume(5);
        }

        public void EndRadio()
        {
            tuner.Off();
            amplifier.Off();
        }
    }
}
