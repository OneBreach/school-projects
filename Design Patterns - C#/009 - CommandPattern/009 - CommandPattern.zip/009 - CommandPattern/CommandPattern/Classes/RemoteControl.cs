﻿using CommandPattern.Classes.Commands;
using CommandPattern.Interfaces;
using System;
using System.Text;

namespace CommandPattern.Classes
{

    //hulp van internet 
    internal class RemoteControl
    {
        Command[] onCommands = new Command[7];
        Command[] offCommands = new Command[7];
        Command undoCommand;

        public RemoteControl()
        {
            Command noCommand = new NoCommand();
            for (int i = 0; i < onCommands.Length; i++)
            {
                onCommands[i] = noCommand;
                offCommands[i] = noCommand;
            }
            undoCommand = noCommand;
        }

        // This method sets the On and Off command to the slot provided
        public void SetCommand(int slot, Command onCommand, Command offCommand)
        {
            if (slot < 0 || slot >= onCommands.Length)
            {
                throw new ArgumentOutOfRangeException("slot", "Invalid slot number.");
            }
            onCommands[slot] = onCommand;
            offCommands[slot] = offCommand;
        }

        // This method calls the OnCommand.Execute() method of the slot provided
        public void OnButtonWasPushed(int slot)
        {
            if (slot < 0 || slot >= onCommands.Length)
            {
                throw new ArgumentOutOfRangeException("slot", "Invalid slot number.");
            }
            onCommands[slot].Execute();
            undoCommand = offCommands[slot]; // Save the corresponding OffCommand for undo
        }

        // This method calls the OffCommand.Execute() method of the slot provided
        public void OffButtonWasPushed(int slot)
        {
            if (slot < 0 || slot >= offCommands.Length)
            {
                throw new ArgumentOutOfRangeException("slot", "Invalid slot number.");
            }
            offCommands[slot].Execute();
            undoCommand = onCommands[slot]; // Save the corresponding OnCommand for undo
        }

        // Method to undo the last command
        public void UndoButtonWasPushed()
        {
            undoCommand.Execute();
        }

        // Overwritten ToString() to print out each slot and its corresponding command.
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("\n----- Remote Control ----- \n");
            for (int i = 0; i < onCommands.Length; i++)
            {
                sb.Append($"[slot {i}] {onCommands[i].GetType().Name} \t\t {offCommands[i].GetType().Name}\n");
            }
            return sb.ToString();
        }
    }
}
