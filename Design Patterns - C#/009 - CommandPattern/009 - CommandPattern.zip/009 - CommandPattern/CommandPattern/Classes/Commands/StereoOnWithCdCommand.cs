﻿using CommandPattern.Interfaces;

namespace CommandPattern.Classes.Commands
{
    internal class StereoOnWithCdCommand : Command
    {
        Stereo stereo;
        int prevState;

        public StereoOnWithCdCommand(Stereo stereo)
        {
            this.stereo = stereo;
        }

        public void Execute()
        {
            prevState = stereo.GetState();
            stereo.On();
            stereo.SetCD();  
        }

        public void Undo()
        {
            switch (prevState)
            {
                case 0:
                    stereo.Off();
                    break;
                case 1:
                    stereo.SetRadio();
                    break;
                case 2:
                    stereo.SetDVD();
                    break;
                case 3:
                    stereo.SetCD();
                    break;
            }
        }
    }
}
