﻿using CommandPattern.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandPattern.Classes.Commands
{
    internal class StereoOnWithDvdCommand : Command
    {
        int prevState;
        Stereo stereo;
        public StereoOnWithDvdCommand(Stereo stereo)
        {
            this.stereo = stereo;
        }
        public void Execute()
        {
            prevState = stereo.GetState();
            stereo.On();
            stereo.SetDVD();
        }

        public void Undo()
        {
            switch (prevState)
            {
                case 0:
                    stereo.Off();
                    break;
                case 1:
                    stereo.SetRadio();
                    break;
                case 2:
                    stereo.SetDVD();
                    break;
                case 3:
                    stereo.SetCD();
                    break;
            }
        }
    }
}
