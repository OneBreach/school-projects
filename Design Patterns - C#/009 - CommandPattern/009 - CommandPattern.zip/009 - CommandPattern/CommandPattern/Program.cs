﻿using CommandPattern.Classes;
using CommandPattern.Classes.Commands;
using CommandPattern.Interfaces;

namespace CommandPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            RemoteControl remoteControl = new RemoteControl();

            Light kitchenLight = new Light("Kitchen Light");
            Light livingRoomLight = new Light("Living Room Light");
            GarageDoor garageDoor = new GarageDoor(new Light("Garage"));
            CeilingFan ceilingFan = new CeilingFan("Living Room"); 
            Stereo stereo = new Stereo(); 

            LightOnCommand kitchenLightOn = new LightOnCommand(kitchenLight);
            LightOffCommand kitchenLightOff = new LightOffCommand(kitchenLight);

            LightOnCommand livingRoomLightOn = new LightOnCommand(livingRoomLight);
            LightOffCommand livingRoomLightOff = new LightOffCommand(livingRoomLight);

            GarageDoorUpCommand garageDoorUp = new GarageDoorUpCommand(garageDoor);
            GarageDoorDownCommand garageDoorDown = new GarageDoorDownCommand(garageDoor);

            CeilingFanOffCommand ceilingFanOff = new CeilingFanOffCommand(ceilingFan);
            CeilingFanHighCommand ceilingFanHigh = new CeilingFanHighCommand(ceilingFan);

            StereoOnWithCdCommand stereoOnWithCdCommand = new StereoOnWithCdCommand(stereo);
            StereoOnWithDvdCommand stereoOnWithDvdCommand = new StereoOnWithDvdCommand(stereo); 
            StereoOnWithRadioCommand stereoOnWithRadioCommand = new StereoOnWithRadioCommand(stereo);   
            StereoOffCommand stereoOff = new StereoOffCommand(stereo);

            NoCommand noCommand = new NoCommand();

            remoteControl.SetCommand(0, livingRoomLightOn, livingRoomLightOff);
            remoteControl.SetCommand(1, kitchenLightOn, kitchenLightOff);
            remoteControl.SetCommand(2, garageDoorUp, garageDoorDown);
            remoteControl.SetCommand(3, ceilingFanOff, ceilingFanHigh); 
            remoteControl.SetCommand(4, stereoOff, noCommand);
            remoteControl.SetCommand(5, stereoOnWithDvdCommand, stereoOff);
            remoteControl.SetCommand(6, stereoOnWithRadioCommand, stereoOff);
            Console.WriteLine(remoteControl);

            remoteControl.OnButtonWasPushed(0); 
            remoteControl.OffButtonWasPushed(0);  
            remoteControl.UndoButtonWasPushed();  

            remoteControl.OnButtonWasPushed(1);   
            remoteControl.OffButtonWasPushed(1);  

            remoteControl.OnButtonWasPushed(2);   
            remoteControl.OffButtonWasPushed(2);

            remoteControl.OnButtonWasPushed(3);
            remoteControl.OffButtonWasPushed(3); 
            remoteControl.UndoButtonWasPushed();

            remoteControl.OffButtonWasPushed(4);  

            remoteControl.UndoButtonWasPushed();  

            remoteControl.OnButtonWasPushed (5);
            remoteControl.OffButtonWasPushed(5);
            remoteControl.UndoButtonWasPushed();
        }
    }
}
