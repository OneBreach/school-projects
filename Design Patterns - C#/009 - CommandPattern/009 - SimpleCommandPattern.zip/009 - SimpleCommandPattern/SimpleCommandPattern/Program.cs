﻿using SimpleCommandPattern.Classes;
using SimpleCommandPattern.Classes.Commands;

namespace SimpleCommandPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Create an instance of SimpleRemoteControl
            SimpleRemoteControl remote = new SimpleRemoteControl();
            Light light = new Light("Woonkamer");
            // Create an instance of Light
            LightOnCommand lightOn = new LightOnCommand(light);
            // Create an instance of LightOnCommand, providing the previous instance of Light as an argument
            LightOffCommand lightOff = new LightOffCommand(light);
            // Create an instance of LightOffCommand, providing the previous instance of Light as an argument
            remote.SetCommand(lightOn);
            // Set the command to the LightOnCommand instance
            remote.ButtonWasPressed();
            remote.SetCommand(lightOff);
            // Set the command to the LightOffCommand instance
            remote.ButtonWasPressed();
            GarageDoor garageDoor = new GarageDoor(light);
            GarageDoorOpenCommand garageDoorOpenCommand = new GarageDoorOpenCommand(garageDoor);
            GarageDoorDownCommand garageDoorDownCommand = new GarageDoorDownCommand(garageDoor);
            remote.SetCommand(garageDoorOpenCommand);

            // Without making another SimpleRemoteControl instance, do the same for the GarageDoorOpenCommand
        }
    }
}