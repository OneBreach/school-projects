﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCommandPattern.Classes
{
    internal class Stereo
    {
        public void On()
        {

        }

        public void Off()
        {

        }

        public void SetCD()
        {

        }

        public void SetDVD()
        {

        }

        public void SetRadio()
        {

        }

        public void SetVolume(int volume)
        {

        }
    }
}
